#!/usr/bin/env bash
set -euo pipefail

PLUGIN_SLUG="dc-shipping-destination-notices"
ZIP_NAME="${PLUGIN_SLUG}.zip"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PLUGIN_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
DISTIGNORE_FILE="${PLUGIN_ROOT}/.distignore"
BUILD_ROOT="${PLUGIN_ROOT}/.build"
STAGING_DIR="${BUILD_ROOT}/${PLUGIN_SLUG}"
OUTPUT_ZIP="${PLUGIN_ROOT}/${ZIP_NAME}"

if ! command -v rsync >/dev/null 2>&1; then
	echo "Error: rsync is required but not installed."
	exit 1
fi

if ! command -v zip >/dev/null 2>&1; then
	echo "Error: zip is required but not installed."
	exit 1
fi

rm -rf "${BUILD_ROOT}" "${OUTPUT_ZIP}"
mkdir -p "${STAGING_DIR}"

RSYNC_ARGS=(
	-a
	--delete
	--exclude=".build"
	--exclude="*.zip"
)

if [[ -f "${DISTIGNORE_FILE}" ]]; then
	RSYNC_ARGS+=(--exclude-from="${DISTIGNORE_FILE}")
fi

rsync "${RSYNC_ARGS[@]}" "${PLUGIN_ROOT}/" "${STAGING_DIR}/"

(
	cd "${BUILD_ROOT}"
	zip -rq "${OUTPUT_ZIP}" "${PLUGIN_SLUG}"
)

rm -rf "${BUILD_ROOT}"

echo "Created ${OUTPUT_ZIP}"
